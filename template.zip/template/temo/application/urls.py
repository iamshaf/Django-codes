from django.contrib import admin
from django.urls import path, include
from . import views
urlpatterns = [
    path('', views.fun1),
    path('index/', views.index, name='index'),
    path('inner/', views.inner, name='inner'),
    path('port/', views.portfolio, name='port')

]
